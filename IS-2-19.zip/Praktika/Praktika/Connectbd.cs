﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Praktika
{
    internal class Connectbd
    {
        public string ConnectBD = "server=caseum.ru;port=33333;user=test_user;database=db_test;password=test_pass;";

        public void Connectioninfo()
        {
            MessageBox.Show(ConnectBD);
        }
    }
}
