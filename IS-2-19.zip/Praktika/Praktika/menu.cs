﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Praktika
{
    public partial class menu : Form
    {
        public menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            zadaniye1 zadaniye1 = new zadaniye1();
            zadaniye1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            zadaniye2 zadaniye2 = new zadaniye2();
            zadaniye2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            zadaniye3 zadaniye3 = new zadaniye3();
            zadaniye3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            zadaniye4 zadaniye4 = new zadaniye4();
            zadaniye4.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            zadaniye5 zadaniye5 = new zadaniye5();
            zadaniye5.ShowDialog();
        }
    }
}
