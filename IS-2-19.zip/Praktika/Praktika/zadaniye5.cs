﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static Praktika.Connectbd;

namespace Praktika
{
    public partial class zadaniye5 : Form
    {
        public zadaniye5()
        {
            InitializeComponent();
        }

        private MySqlDataAdapter MyDA = new MySqlDataAdapter();
        private BindingSource bSource = new BindingSource();
        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionDB connectionDB = new ConnectionDB();
            string dateitimeStud = textBox2.Text;
            string fioStud = textBox1.Text;
            string sql = $"INSERT INTO t_PraktStud (fioStud, datetimeStud) VALUES ('{fioStud}','{dateitimeStud}');";
            try
            {
                connectionDB.connDB().Open();
                MyDA.SelectCommand = new MySqlCommand(sql, connectionDB.connDB());
            }
            finally
            {
                    connectionDB.connDB().Close();
            }
        }
    }

}
